package servlet;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson; // Gson 임포트

// 서블릿 매핑 (web.xml 또는 어노테이션) 
public class SaveServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException {
        
        request.setCharacterEncoding("UTF-8");
        String keyword = request.getParameter("keyword");
        
        // 1. Naver API 호출 (SearchServlet과 거의 동일)
        String clientId = "DEnAduSJfA5trBjgf0iV"; 
        String clientSecret = "JkTcUGsuBB";
        String encodedKeyword = URLEncoder.encode(keyword, "UTF-8");
        String apiURL = "https://openapi.naver.com/v1/search/blog.json?query=" + encodedKeyword + "&display=100";
        
        String responseBody = "";
        try {
            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("X-Naver-Client-Id", clientId);
            con.setRequestProperty("X-Naver-Client-Secret", clientSecret);
            
            int responseCode = con.getResponseCode();
            BufferedReader br = (responseCode == 200) ? 
                new BufferedReader(new InputStreamReader(con.getInputStream())) :
                new BufferedReader(new InputStreamReader(con.getErrorStream()));
            
            String inputLine;
            StringBuffer apiResponse = new StringBuffer();
            while ((inputLine = br.readLine()) != null) {
                apiResponse.append(inputLine);
            }
            br.close();
            responseBody = apiResponse.toString();
        } catch (Exception e) {
            request.setAttribute("message", "API 호출 실패: " + e.getMessage());
        }

        // 2. Gson으로 JSON 파싱 (SearchServlet과 동일)
        List<BlogItem> items = null;
        try {
            Gson gson = new Gson();
            BlogResponse blogResponse = gson.fromJson(responseBody, BlogResponse.class);
            items = blogResponse.getItems();
        } catch (Exception e) {
             request.setAttribute("message", "JSON 파싱 실패: " + e.getMessage());
        }

        // ---------------------------------------------------------------
        // 3. ★★★ 기억하신 DB 저장 로직 ★★★
        // ---------------------------------------------------------------
        String dbMessage = "";
        if (items != null) {
            Connection conn = null;
            PreparedStatement stmt = null;
            int insertCount = 0;
            
            try {
                // [기억한 코드] 1. 드라이버 로드
                Class.forName("com.mysql.cj.jdbc.Driver");
                // [기억한 코드] 2. 커넥션 (DB명, ID, PW 확인)
                conn = DriverManager.getConnection("jdbc:mysql://localhost/db_server","db202445018","db202445018");
                // [수정된 코드] 3. SQL 준비
                String sql = "INSERT INTO naver_search_results (keyword, title, link, description, bloggername) VALUES (?, ?, ?, ?, ?)";
                stmt = conn.prepareStatement(sql);
                
                for(BlogItem item : items) {
                    stmt.setString(1, keyword); 
                    stmt.setString(2, item.getTitle());
                    stmt.setString(3, item.getLink());
                    stmt.setString(4, item.getDescription());
                    stmt.setString(5, item.getBloggername());
                    
                    stmt.executeUpdate();
                    insertCount++;
                }
                
                dbMessage = "DB 저장 성공! 총 " + insertCount + "건이 저장되었습니다.";
                
            } catch(Exception e) {
                e.printStackTrace();
                dbMessage = "DB 저장 실패: " + e.getMessage();
            } finally {
                // [기억한 코드] 5. 자원 해제
                try { if(stmt != null) stmt.close(); } catch (Exception e) {}
                try { if(conn != null) conn.close(); } catch (Exception e) {}
            }
        }
        
        // 4. 결과를 save.jsp로 전달
        request.setAttribute("message", dbMessage);
        RequestDispatcher dispatcher = request.getRequestDispatcher("save.jsp");
        dispatcher.forward(request, response);
    }
}
