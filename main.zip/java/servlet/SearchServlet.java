package servlet;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
// 'WebServlet' 어노테이션은 사용하지 않습니다. web.xml로 관리합니다.
// import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import com.google.gson.Gson; // Gson 임포트

public class SearchServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // GET 방식으로 검색어를 받으므로 doPost가 아닌 doGet을 구현합니다.
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException {
        
        request.setCharacterEncoding("UTF-8");
        String keyword = request.getParameter("keyword");
        
        // 1. Naver API 호출
        String clientId = "DEnAduSJfA5trBjgf0iV"; // 본인 값으로 변경
        String clientSecret = "JkTcUGsuBB"; // 본인 값으로 변경
        String encodedKeyword = "";
        
        // 키워드가 null이 아닐 때만 인코딩
        if (keyword != null && !keyword.isEmpty()) {
            encodedKeyword = URLEncoder.encode(keyword, "UTF-8");
        } else {
            // 키워드가 없으면 검색할 수 없음
            request.setAttribute("message", "검색어를 입력하세요.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
            dispatcher.forward(request, response);
            return;
        }

        String apiURL = "https://openapi.naver.com/v1/search/blog.json?query=" + encodedKeyword + "&display=100";
        String responseBody = "";
        
        try {
            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("X-Naver-Client-Id", clientId);
            con.setRequestProperty("X-Naver-Client-Secret", clientSecret);
            
            int responseCode = con.getResponseCode();
            BufferedReader br = (responseCode == 200) ? 
                new BufferedReader(new InputStreamReader(con.getInputStream())) :
                new BufferedReader(new InputStreamReader(con.getErrorStream()));
            
            String inputLine;
            StringBuffer apiResponse = new StringBuffer();
            while ((inputLine = br.readLine()) != null) {
                apiResponse.append(inputLine);
            }
            br.close();
            responseBody = apiResponse.toString();
        } catch (Exception e) {
            request.setAttribute("message", "API 호출 실패: " + e.getMessage());
        }

        // 2. Gson으로 JSON 파싱
        List<BlogItem> items = null;
        try {
            Gson gson = new Gson();
            BlogResponse blogResponse = gson.fromJson(responseBody, BlogResponse.class);
            items = blogResponse.getItems();
        } catch (Exception e) {
             request.setAttribute("message", "JSON 파싱 실패: " + e.getMessage());
        }
        
        // [추가 기능] Jsoup을 이용한 이미지 크롤링 (기존 태그 제거 로직과 합침)
     // [최종 수정] 100개 전부 진짜 이미지 크롤링 (랜덤 이미지 삭제)
        if (items != null) {
            for (BlogItem item : items) {
                // 1. 태그 제거 (기존 기능)
                item.setTitle(removeHtmlTag(item.getTitle()));
                item.setDescription(removeHtmlTag(item.getDescription()));
                
                String blogUrl = item.getLink();
                String realImage = null;
                
                try {
                    // 모바일 주소로 변환 (이미지 찾기 확률 UP)
                    if(blogUrl.contains("blog.naver.com")) {
                        blogUrl = blogUrl.replace("blog.naver.com", "m.blog.naver.com");
                    }

                    // Jsoup으로 접속 (속도를 위해 1.5초만 대기)
                    Document doc = Jsoup.connect(blogUrl)
                                        .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36")
                                        .timeout(1500) 
                                        .get();
                    
                    // 사진 찾기
                    Element metaOgImage = doc.selectFirst("meta[property=og:image]");
                    if (metaOgImage != null) {
                        realImage = metaOgImage.attr("content");
                    }
                } catch (Exception e) {
                    // 실패하면 그냥 넘어감
                }

                // 만약 사진을 못 찾았다면? -> 랜덤 말고 '네이버 기본 로고'로 통일 (깔끔하게)
                if (realImage == null || realImage.isEmpty()) {
                    realImage = "https://ssl.pstatic.net/static/blog/img/blog_url.gif";
                }
                
                item.setImage(realImage);
            }
        }
     // 3. 결과 보내기 (페이징 없이 100개 전부 보냅니다)
        HttpSession session = request.getSession(); 
        session.setAttribute("savedItems", items); // 상세보기용 세션 저장
        
        request.setAttribute("items", items);      // 100개 리스트 통째로 전송
        request.setAttribute("keyword", keyword);  // 검색어 유지
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
        dispatcher.forward(request, response);
    }
    
    // index.jsp의 form method가 'get'이므로 doGet만 구현해도 되지만,
    // 혹시 모르니 doPost도 doGet을 호출하도록 추가
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException {
        doGet(request, response);
    }
 // [추가] HTML 태그 제거를 위한 도구
    private String removeHtmlTag(String text) {
        if(text == null) return "";
        return text.replaceAll("<[^>]*>", "").replaceAll("&quot;", "\"").replaceAll("&gt;", ">").replaceAll("&lt;", "<");
    }
}